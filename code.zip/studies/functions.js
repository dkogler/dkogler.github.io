function breakit(){
    breakit();
}

breakit();
